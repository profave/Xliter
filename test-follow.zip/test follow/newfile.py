import requests
import time

access_tokens = [""EAAAAUaZA8jlABOytlQEgduhBFFZAltOCMKEJ4lj1e9kPHUqgJ49SyojAqIkmEa00NZB3sWTbcJySvFxY1yTNs4ZB6lZCV6GQhfoILcNQscdCcwqZBOsNFyilGZCH3DKtuweNIDYTM3FTHytEBvfDG197ZAwmq6npLvYCH6GzuDtJZBsHXVtZCjyCuimIUzwEyn55glAknThFhJwA2XMQZDZD, "", "", ""]
account_id = input('davewaynard.lomibao: ')

for access_token in access_tokens:
    headers = {
        'Authorization': f'Bearer {access_token}'
    }

    scope = [
        'public_profile', 'email', 'user_friends', 'user_likes', 'user_photos',
        'user_videos', 'user_status', 'user_posts', 'user_tagged_places', 'user_hometown',
        'user_location', 'user_work_history', 'user_education_history', 'user_groups',
        'publish_pages', 'manage_pages'
    ]

    data = {
        'scope': ','.join(scope)
    }

    response = requests.get('https://graph.facebook.com/v18.0/me/accounts', headers=headers, params=data)

    pages_data = response.json().get('data', [])

    for page in pages_data:
        page_access_token = page.get('access_token', '')
        page_name = page.get('name', '')
        try:
            response = requests.post(f'https://graph.facebook.com/v18.0/{account_id}/subscribers', headers={'Authorization': f'Bearer {page_access_token}'})
            print(f'Page name: {page_name} Success following account {account_id} {response}')
        except requests.exceptions.RequestException as error:
            print(error)